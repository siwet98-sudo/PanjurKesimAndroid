# Panjur Kesim Android

Bu proje, yüklenen Panjur Kesim Hesaplama HTML uygulamasını Android WebView içinde çalıştırır.

## Telefonda GitHub ile APK oluşturma
1. Bu ZIP dosyasını açmadan GitHub'da yeni bir depo oluştur: `PanjurKesimAndroid`.
2. Depoda **Add file → Upload files** seçeneğiyle ZIP'i doğrudan yüklemek yerine önce ZIP'i telefonunda çıkart ve içindeki dosya/klasörleri yükle. `.github/workflows/build-apk.yml` dosyası da dahil olmalı.
3. GitHub deposunda **Actions** sekmesine gir.
4. Solda **Panjur Kesim APK oluştur** iş akışını seç ve **Run workflow** düğmesine bas.
5. İşlem tamamlanınca çalıştırma kaydını aç. **Artifacts** bölümündeki `PanjurKesim-APK` dosyasını indir.
6. İndirilen ZIP'i aç, `app-debug.apk` dosyasına dokun ve Android'in kurulum adımlarını izle.

APK henüz imzalanmış bir mağaza sürümü değildir; bu, telefona test amaçlı kurulabilen debug APK'dır.
